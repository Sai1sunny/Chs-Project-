export const environment = {
  production: true,
  baseUrl: 'https://my-spring-social-network2.herokuapp.com/',
};
