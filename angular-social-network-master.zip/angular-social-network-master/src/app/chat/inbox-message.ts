export class InboxMessage {
  with: string = '';
  content: string = '';
  time: string = '';
  newMessages: number = 0;
}
