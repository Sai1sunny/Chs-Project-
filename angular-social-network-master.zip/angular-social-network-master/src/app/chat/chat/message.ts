export class MessageDto {
  content: string = '';
  from: string = '';
  to: string = '';
  time: string = '';
}
