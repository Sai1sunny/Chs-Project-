export class Frame {
  body: string = '';
}
