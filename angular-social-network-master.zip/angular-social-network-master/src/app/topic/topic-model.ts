export interface TopicModel {
  id: number;
  name: string;
  description: string;
  numberOfPosts: number;
}
