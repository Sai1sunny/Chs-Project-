export interface CommentModel {
  id: number;
  postId: number;
  text: string;
  username: string;
  duration: string;
}
