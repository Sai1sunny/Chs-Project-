import { ReactionType } from './reaction-type';

export interface ReactionModel {
  postId: number;
  reactionType: ReactionType;
}
