export enum ReactionType {
  LIKE,
  DISLIKE,
}
