export class NotificationModel {
  id: number = 0;
  postId: number = 0;
  message: string = '';
  read: boolean = false;
}
