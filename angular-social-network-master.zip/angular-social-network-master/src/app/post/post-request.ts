export interface PostRequest {
  title: string;
  topicName: string;
  content: string;
}
