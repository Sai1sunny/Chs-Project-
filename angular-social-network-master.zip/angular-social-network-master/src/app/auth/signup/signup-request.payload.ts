export interface SignupRequestPaylaod{
    username:string;
    email:string;
    password:string;
}

