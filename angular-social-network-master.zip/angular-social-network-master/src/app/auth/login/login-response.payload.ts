export interface LoginResponse {
  authenticationToken: string;
  username: string;
  isAdmin: boolean;
}
