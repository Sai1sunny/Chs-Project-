export class ReportedUserModel {
    username: string = '';
    numberOfViolations: number = 0;
    enabled: boolean = true;
}