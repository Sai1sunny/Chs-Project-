export interface Ip {
  ip: string;
}
