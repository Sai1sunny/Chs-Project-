export interface Location {
  country_name: string;
  city: string;
}
