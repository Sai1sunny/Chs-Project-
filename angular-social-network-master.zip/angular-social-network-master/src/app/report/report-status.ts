export enum ReportStatus {
  UNSOLVED,
  APPROVED,
  DELETED,
}
