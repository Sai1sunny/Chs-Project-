export enum ReportType {
  VIOLENCE,
  NUDITY,
  CURSING,
}
